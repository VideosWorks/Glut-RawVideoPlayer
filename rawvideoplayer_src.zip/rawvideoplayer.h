/*****************************************************************************

FileName: <rawvideoplayer.h>

Description:
	Header File for rawvideoplayer modules

*****************************************************************************/


void GenOutputBuf();

